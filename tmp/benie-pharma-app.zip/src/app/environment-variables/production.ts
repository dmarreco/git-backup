export const prodVariables = {
	_REGION: "us-west-2",
	_IDENTITY_POOL_ID: "us-west-2:3a89f0c4-ef73-4aad-890b-81a1cc90ae0a",
	_USER_POOL_ID: "us-west-2_0upQBJJB3",
	_CLIENT_ID: "3rfjbrshro80qtgpg5c3v06rfj",
	_MOBILE_ANALYTICS_APP_ID: "2fe3a4e15c1d43c998892b5313a76fa3",
	_POOL_DATA: {
	    UserPoolId: "us-west-2_0upQBJJB3",
	    ClientId: "3rfjbrshro80qtgpg5c3v06rfj"
	},

	_ENDPOINT: "https://of14631z2h.execute-api.us-west-2.amazonaws.com/prod",
	_ENV: "PROD"
}