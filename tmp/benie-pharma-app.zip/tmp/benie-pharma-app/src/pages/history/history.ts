import { Component, ViewChild } from '@angular/core';
import { Events, reorderArray, ModalController } from 'ionic-angular';
import { OrderDetailsPage } from '../order-details/order-details';
import { OrderProvider } from '../../providers/order/order.service';
import { STATUS } from '../../models/order.model';
import { ConnectivityProvider } from '../../providers/connectivity/connectivity';
import { LoadingController, AlertController } from 'ionic-angular';
import { OrderListComponent } from '../../components/order-list/order-list';

@Component({
  selector: 'page-history',
  templateUrl: 'history.html'
})
export class History {

  @ViewChild('orderList')
    orderList:OrderListComponent;

  // @ViewChild('orderListNotAccepted')
  //   orderListNA:OrderListComponent;

 public orders;
  alert: any;

  constructor(public orderService: OrderProvider, public alertCtrl: AlertController, public connectivityService: ConnectivityProvider, public events: Events, public modalCtrl: ModalController, public loadingCtrl: LoadingController) {
    if(this.connectivityService.isOnline()){
    }else{
      this.addConnectivityListeners();
    }
  }

  ionViewDidLoad(){
     this.doRefresh(0, true);
     this.events.subscribe('changed_to_'+STATUS.READY, () => {
       console.log("Refresh");
       this.doRefresh(0);
     })
     this.events.subscribe('changed_to_'+STATUS.NOT_ACCEPTED, () => {
       console.log("Refresh Not Accepted")
       this.doRefresh(0);
     })
  }
  
  doRefresh(refresher, init?:boolean) {
    this.orderList.refreshOrder(init).subscribe(() => {
      if (refresher.complete)
        refresher.complete();
    });
    //this.orderListNA.refreshOrder(init).subscribe(() => {})
  }

  viewOrderDetails(order){
    let pageDetails = this.modalCtrl.create(OrderDetailsPage, {order: order});
    pageDetails.onDidDismiss(() => {
      this.doRefresh(0);
    });
    pageDetails.present();
  }

  reorderItems(indexes) {
    this.orders = reorderArray(this.orders, indexes);
  }
  
  addConnectivityListeners(): void {

   this.connectivityService.watchOnline().subscribe(() => {

     console.log("online");

     setTimeout(() => {

     }, 2000);

   });

   this.connectivityService.watchOffline().subscribe(() => {

     console.log("offline");
     this.alert.present();

   });

  }

  showAlert() {
    this.alert = this.alertCtrl.create({
      title: 'Sem conexão com a Internet',
      subTitle: 'Conecte-se e tente novamente!',
      buttons: ['OK']
    });
  }
}
