export const qaVariables = {
	_REGION: "us-west-2",
	_IDENTITY_POOL_ID: "us-west-2:3a89f0c4-ef73-4aad-890b-81a1cc90ae0a",
	_USER_POOL_ID: "us-west-2_H7KXXwGgC",
	_CLIENT_ID: "7ln2osqt7hqtpldt1eafgd4djj",
	_MOBILE_ANALYTICS_APP_ID: "62b29b879d8a46129a9283497117305c",
	_POOL_DATA: {
	    UserPoolId: "us-west-2_H7KXXwGgC",
	    ClientId: "7ln2osqt7hqtpldt1eafgd4djj"
	},
	_ENDPOINT: "https://r08uzkjsyh.execute-api.us-west-2.amazonaws.com/test",
	_ENV: "QA"
}
