import { Component, ViewChild } from '@angular/core';
import { Platform, NavController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Events } from "ionic-angular/index";

import { TabsPage } from '../pages/tabs/tabs';
import { LoginPage } from '../pages/login/login';

import {UserLoginService} from "../providers/login/userLogin.service";
import {EventsService} from "../providers/login/events.service";
import {AwsUtil} from "../providers/login/aws.service";
import {PushNotificationService} from "../providers/push-notification/push-notification.service";
import{ _USER_LOGOUT_EVENT } from "../providers/login/events.service";

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild('myNav') nav: NavController
  rootPage:any;

  constructor(platform: Platform, 
              statusBar: StatusBar, 
              private splashScreen: SplashScreen, 
              private userService: UserLoginService,
              private eventService: EventsService,
              private events: Events,
              private awsUtil: AwsUtil,
              private pushNotificationService: PushNotificationService) {
    platform.ready().then(() => {
      statusBar.styleDefault();
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.

      if(window["plugins"]) {
        this.pushNotificationService.setup();
      }
    });
  }

  ngOnInit() {
    this.userService.isAuthenticated().then(
        res => {
            this.eventService.sendLoggedInEvent();
            this.nav.setRoot(TabsPage);
            console.log("Logged in");
            this.splashScreen.hide();
            this.awsUtil.setupAWS(true);
        },
        err => {
            this.nav.setRoot(LoginPage);
            this.splashScreen.hide();
            console.log("Must login");
        }
    );
    this.setupListeners();
  }

  setupListeners() {
    this.events.subscribe(_USER_LOGOUT_EVENT, ()=> {
        this.nav.setRoot(LoginPage);
    });
  }
}
