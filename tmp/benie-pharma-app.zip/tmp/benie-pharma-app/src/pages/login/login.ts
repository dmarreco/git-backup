import { Subscriber } from 'ionic-native/node_modules/rxjs';
import {Component} from "@angular/core";
import {CognitoCallback, LoggedInCallback} from "../../providers/login/cognito.service";
import {AlertController, NavController, NavParams} from "ionic-angular";
import {UserLoginService} from "../../providers/login/userLogin.service";
import {EventsService} from "../../providers/login/events.service";
import {TabsPage} from "../tabs/tabs";

@Component({
    templateUrl: 'login.html'
})
export class LoginPage implements CognitoCallback, LoggedInCallback {
    email: string;
    password: string;
    processing: boolean = false;

    constructor(public nav: NavController,
                public navParam: NavParams,
                public alertCtrl: AlertController,
                public userService: UserLoginService,
                public eventService: EventsService) {
        console.log("LoginComponent constructor");
        if (navParam != null && navParam.get("email") != null)
            this.email = navParam.get("email");

    }

	logout(){
		console.log("log out!");
		this.userService.logout();
	}

    signMeIn() {
        console.log("in onLogin");
        if (this.email == null || this.password == null) {
            this.doAlert("Erro", "Todos os campos são obrigatórios");
            return;
        }
        this.processing = true;
        this.userService.authenticate(this.email, this.password, this);
    }

    cognitoCallback(message: string, result: any) {
        this.processing = false;
        if (message != null) { //error
            this.doAlert("Error", message);
            console.log("result: " + message);
        } else { //success
            console.log("Redirect to Home Page");
            this.nav.setRoot(TabsPage);
        }
    }

    isLoggedInCallback(message: string, isLoggedIn: boolean) {
        console.log("The user is logged in: " + isLoggedIn);
        if (isLoggedIn) {
            this.eventService.sendLoggedInEvent();
            this.nav.setRoot(TabsPage);
        }
    }

    doAlert(title: string, message: string) {

        let alert = this.alertCtrl.create({
            title: title,
            subTitle: message,
            buttons: ['OK']
        });
        alert.present();
    }

}