import { Component, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';

import { LocationProvider } from '../../providers/location/location';
import { Order, STATUS } from '../../models/order.model';

/**
 * Generated class for the OrderComponent component.
 *
 * See https://angular.io/docs/ts/latest/api/core/index/ComponentMetadata-class.html
 * for more info on Angular Components.
 */
@Component({
  selector: 'order',
  templateUrl: 'order.html'
})

export class OrderComponent {
  public _order:Order;
  public _admin:boolean;

  @Input() set order(o:Order) {
    this._order = o;
    this.updatePosition()
  }

  get order():Order { return this._order};

  @Input() set admin(a:boolean) {
    this._admin = a;
  }

  get admin():boolean { return this._admin };

  private _currentTime:number = 0;
  @Input() set currentTime(val: number) {
    this._currentTime = val;
    this.updateTime();
  }

  @Input() colorCard: string;

  @Output() accept:EventEmitter<OrderComponent> = new EventEmitter<OrderComponent>();
  @Output() reject:EventEmitter<OrderComponent> = new EventEmitter<OrderComponent>();
  @Output() info:EventEmitter<Order> = new EventEmitter<Order>();

  @ViewChild('check') check:ElementRef;
  @ViewChild('close') close:ElementRef;

  public deadline:number = 0;
  public deadlineLabel:string = 'segundos';
  public currentLocation:any = {};
  public distance: number;
  public alpha: number;
  public checkmarkOpacity: boolean = false;
  public closeOpacity: boolean = false;

  public goLeft:boolean = false;
  public goRight:boolean = false;

  constructor(private location:LocationProvider) {
    this._currentTime = (new Date()).getTime();
  }

  ionViewDidEnter() {
    //this.updateTime();
    console.log('COLOR');
    console.log(this.colorCard);
  }

  updatePosition() {
    if (!this._order.location) return;
    this.location.distanceFrom(this._order.location.lat, this._order.location.lng)
     .subscribe(
       (dist) => {this.distance = dist},
       (err) => {console.log(err)}
     );
  }

  getProductPrice(ean: string, cartIndex) {
    let product;

    if(this._order.invoice && this._order.invoice.items) {
      product = this._order.invoice.items.filter(elem => {
        return elem.ean == ean
      });
      
      return product[0].vendorPrice;
    }

    product = this._order.cart[cartIndex].product;

    return product.price;
  }

  updateTime() {
    if (!this._order.deadlineTime) return;

    let timeDif = this._order.deadlineTime - this._currentTime;
    let seconds = timeDif/1000.0;

    this.deadline = Math.floor(seconds);
    this.deadlineLabel = 'segundos';

    if (this.deadline <= 0) { 
      this.deadlineLabel = 'Entrega atrasada'
    };

    let minutes = seconds/60;
    let tempdeadline = Math.floor(minutes);
    if (tempdeadline <= 0) return;
    this.deadline = tempdeadline;
    this.deadlineLabel = tempdeadline > 1 ? 'minutos' : 'minuto';

    let hours = minutes/60;
    tempdeadline = Math.floor(hours);
    if (tempdeadline <= 0) return;
    this.deadline = tempdeadline;
    this.deadlineLabel = tempdeadline > 1 ? 'horas' : 'hora';

    let days = hours/24;
    tempdeadline = Math.floor(days);
    if (tempdeadline <= 0) return;
    this.deadline = tempdeadline;
    this.deadlineLabel = tempdeadline > 1 ? 'dias' : 'dia';
  }

  onDrag(item) {
    let percent = item.getSlidingPercent();
    if (this._order.status === STATUS.ACCEPTED && percent > 1) {
      item.close();
    }
    if (this._order.status === STATUS.READY || this._order.status === STATUS.NOT_ACCEPTED) {
      item.close();
    }
    if (item._openAmount > 30) {
      this.close.nativeElement.style.opacity = .6;
    } 
    if (item._openAmount < -30) {
      this.check.nativeElement.style.opacity = .6;
    }
    if (Math.abs(item._openAmount)<30) {
      this.close.nativeElement.style.opacity = 0;
      this.check.nativeElement.style.opacity = 0;
    }
  }

  acceptOrder() {
    //if (this.order.status === STATUS.READY) return;
    this.goRight = true;
    setTimeout(() => {
      this.accept.emit(this);      
    }, 300);
    //this.accept.emit(this._order);
  }

  rejectOrder() {
    if (this.order.status !== STATUS.ORDERED) return;
    this.goLeft = true;
    setTimeout(() => {
      this.reject.emit(this);
    }, 300);
  }

  infoOrder() {
    this._order['admin'] = this.admin;
    this.info.emit(this._order);
  }

  resetStyle() {
    this.goRight = false;
    this.goLeft = false;
    this.close.nativeElement.style.opacity = 0;
    this.check.nativeElement.style.opacity = 0;
  }

  onSwipe(event) {
  }


}