import { Injectable, Inject } from "@angular/core";
import { EnvVariables } from '../../app/environment-variables/environment-variables.token'

@Injectable()
export class CognitoConstants {

  constructor(@Inject(EnvVariables) private envVariables) {
    console.log("Env Variables:", envVariables);
  }

  public get _REGION():string {
    return this.envVariables._REGION;
  }

  public get _IDENTITY_POOL_ID():string {
    return this.envVariables._IDENTITY_POOL_ID;
  }

  public get _USER_POOL_ID():string {
    return this.envVariables._USER_POOL_ID;
  }

  public get _CLIENT_ID():string {
    return this.envVariables._CLIENT_ID;
  }

  public get _MOBILE_ANALYTICS_APP_ID():string {
    return this.envVariables._CLIENT_ID;
  }

  public get _POOL_DATA():any {
    return {
      UserPoolId: this._USER_POOL_ID,
      ClientId: this._CLIENT_ID
    };
  }

  public get _ENDPOINT():string {
    return this.envVariables._ENDPOINT;
  }

  public get _ENV():string {
    return this.envVariables._ENV;
  }

}