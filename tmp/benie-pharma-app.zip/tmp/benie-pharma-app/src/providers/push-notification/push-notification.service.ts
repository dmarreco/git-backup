import {Events} from "ionic-angular/index";
import {Injectable} from '@angular/core';

import{_USER_LOGOUT_EVENT, _USER_LOGIN_EVENT} from "../../providers/login/events.service";

@Injectable()
export class PushNotificationService {

  private static _oneSignal;
  private static _playerID;

  constructor(private events: Events) {
  }

  setup() {
      let OneSignal = window["plugins"].OneSignal;

      if(!OneSignal) {
        console.error("OneSignal Plugin not found");
        return;
      }

      PushNotificationService._oneSignal = OneSignal;

      PushNotificationService._oneSignal
        .startInit("f1f30645-3ed6-4fff-9c93-5b4ca1b62236", "134112068584")
        .handleNotificationOpened(this.notificationOpenedCallback)
        .handleNotificationReceived(this.notificationReceivedCallback)
        .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.None)
        .endInit();

      PushNotificationService._oneSignal.getIds(function(ids) {
        console.log("#OneSignal IDS", ids);
        //Persistir isso em algum lugar
        PushNotificationService._playerID = ids.userID;
      });

      this.setupListeners();
  }

  notificationOpenedCallback(jsonData) {
    console.log('notificationOpenedCallback: ' + JSON.stringify(jsonData));
  }

  notificationReceivedCallback(jsonData) {
    console.log('notificationReceivedCallback: ' + JSON.stringify(jsonData));
  }

  setupListeners() {
    this.events.subscribe(_USER_LOGIN_EVENT, ()=> {
        PushNotificationService._oneSignal. sendTag("logged", "true");
    });

    this.events.subscribe(_USER_LOGOUT_EVENT, ()=> {
        PushNotificationService._oneSignal. sendTag("logged", "false");
    });
  }
}
