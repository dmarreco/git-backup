import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Events } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';
import { tap, retry } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/publishReplay'

import { CognitoUtil } from "../login/cognito.service";
import { CognitoConstants } from "../login/properties.service";
import { AwsUtil } from "../login/aws.service";
import { _USER_LOGIN_EVENT, _USER_LOGOUT_EVENT } from "../login/events.service";
import { ConnectivityProvider } from "../connectivity/connectivity";
import { ToastService } from "../toast/toast.service";

/*
  Generated class for the HttpProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
@Injectable()
export class HttpProvider {

  private static _loggedIn:boolean = false;

  constructor(
    public http: Http,
    public cUtil: CognitoUtil,
    private constants: CognitoConstants,
    private awsUtil:AwsUtil,
    private connectivity:ConnectivityProvider,
    private toast:ToastService,
    private events:Events) {
    this.events.subscribe(_USER_LOGIN_EVENT, this.onLogin);
    this.events.subscribe(_USER_LOGOUT_EVENT, this.onLogout);
  }

  onLogin() {
    HttpProvider._loggedIn = true;
  }
  onLogout() {
    HttpProvider._loggedIn = false;
  }

  public get<T>(url:string): Observable<T> {
    
    if (this.connectivity.isOffline()) {
      
      let observ = new Observable<T>((observable) => {
        observable.error("No internet connection");
      });
      observ.catch((a,b) => {return Observable.throw("No internet connection")})
      return observ;

    } else {
      let options = this._getRequestOptions();
      let observ:Observable<T> = this.http
        .get(this.constants._ENDPOINT+url, options)
        .map(res => res.json() as T)
        .pipe(
          retry(5),
          tap(
            res => {},
            err => {this.handleError(err)}
          )
        ).publishReplay(1).refCount()
        .catch(
          (err) => {
            console.log("catching error: ", err)
            return Observable.throw(err);
        });;
      return observ;     
    }

  }

  public post(url:string, data): Observable<any> {
        
    if (this.connectivity.isOffline()) {
      
      let observ = new Observable<any>((observable) => {
        observable.error("No internet connection")
      });
      observ.catch((a,b) => {return Observable.throw("No internet connection")})
      return observ; //Observable.throw('No internet connection');

    } else {
      let options = this._getRequestOptions();
      let observ:Observable<any> = this.http.post(this.constants._ENDPOINT+url, data, options)
              .map(res => res.json()).pipe(
                tap(
                  res => {},
                  err => {this.handleError(err)}
                )
              ).publishReplay(1).refCount()
              .catch(
                (err) => {
                  console.log("catching error: ", err)
                  return Observable.throw(err);
              });
      return observ;
    }
  }

  private handleError(e:any) {
    console.log("error in http (error && logged):", e, HttpProvider._loggedIn);
    let errorReport:any = {
      "url": e.url,
      "body": e._body
    }
    errorReport.message = "Erro de http status:"+e.status;
    if (e.status == 412) {
      errorReport.type = "precondition_failed";
      this.warnError("Infelizmente este pedido já foi aceito por outro usuário!");
    } else if (!HttpProvider._loggedIn && e.status == 401) {
      console.log("don't need to show 401 error if not logged in");
    } else if (e.status == 500) {
      errorReport.type = "server_error 500";
      this.warnError("Ocorreu um erro de conectividade, tente novamente em alguns instantes.");
    } else {
      errorReport.type = "erro_nao_classificado status: "+e.status;
      this.warnError("Ocorreu um erro de conectividade, tente novamente em alguns instantes.");
      console.error("Erro de conectividade:", e);
    }
    this.awsUtil.recordEvent(errorReport.type, errorReport);
    return e;
  }

  private warnError(errorMessage:string) {
    this.toast.error(errorMessage);
  }

  private _getRequestOptions():RequestOptions {

    let token = this._getIdToken();
    let headers = new Headers();
    
        headers.append('Content-Type', 'application/json');
        headers.append('Authorization', token);
    
    return new RequestOptions({ headers: headers });
  }
  
  private _getIdToken(): string {
    let token = "";
    this.cUtil.getIdToken({
      callback() { },
      callbackWithParam(idToken: any) {
        token = idToken;
      }
    });
    return token;
  }

}
