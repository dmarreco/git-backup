import { Component } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Events, NavParams, ViewController } from 'ionic-angular';
 
import { OrderProvider } from '../../providers/order/order.service';
import { LocationProvider } from '../../providers/location/location';
import { finalize } from 'rxjs/operators/finalize';

@Component({
  selector: 'page-order-details',
  templateUrl: 'order-details.html',
})
export class OrderDetailsPage {

  loader: any;
  address;
  complement;
  encodeAddress;
  cart;
  status;
  userId;
  timestamp;
  totalPrice;
  googleMapsImage;
  order;
  distance:any;
  admin:boolean;

  public processingOrder: boolean = false;
  public styleDetail: string;

  public vendorPriceForm: FormGroup;
  private _vendorPrices: any = {};
  
  
  constructor(
    public navParams: NavParams, 
    public viewCtrl: ViewController,
    public orderService: OrderProvider,
    public events: Events,
    private location:LocationProvider,
    private formBuilder: FormBuilder) {
  }

  ionViewDidLoad() {
    this.order = this.navParams.get('order');
    this.address = this.navParams.get('order').location.address;
    this.complement = this.navParams.get('order').location.complement || false;
    this.encodeAddress = encodeURI(this.address);
    this.cart = this.navParams.get('order').cart;
    this.status = this.navParams.get('order').status;
    this.userId = this.navParams.get('order').userId;
    this.timestamp = this.navParams.get('order').timestamp;
    this.totalPrice = this.navParams.get('order').totalPrice;
    this.admin = this.navParams.get('order').admin;

    console.log('ORDER FROM EMISSION', this.order);
    console.log('ADMIN STATUS', this.admin);

    // this.loader.dismiss();
    this.updatePosition();

    this.setStyleByStatus(this.status);
    this.buildVendorPriceForm();
  }
      
  buildVendorPriceForm() {
    let formControls = {};

    this.cart.forEach( item => {
      formControls[item.product.ean] = new FormControl(null, [Validators.required, Validators.min(0.01)]);
      
      item.product.correctedEan = `${item.product.ean}-corrected`;
      formControls[item.product.correctedEan] = new FormControl(null, [Validators.required]);
      formControls[item.product.correctedEan].setValue(item.product.ean);
    });

    this.vendorPriceForm = this.formBuilder.group(formControls);
  }

  getInvoicePrice(ean: string) {
    if(!this.order.invoice) { return; }
    
    let product = this.order.invoice.items.filter(elem => { return elem.ean === ean });
    return product[0].vendorPrice;
  }

  getformControl(control: string) {
    let formControl = this.vendorPriceForm.controls[control];
    return formControl;
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }

  changeOrderStatus(order){
    let metadata;
    if(this.status == 'ORDERED') {
      if (this.vendorPriceForm.invalid) { 
        this.triggerValidateFormFields(this.vendorPriceForm);
        return; 
      }

      const partitionHash = (hash, keyCondition) => {
        let [trueHash, falseHash] = [{}, {}];

        Object.keys(hash).map(key => {
          if (key.includes(keyCondition)) {
            let newKey = key.slice(0, key.length - keyCondition.length);
            if (newKey !== hash[key]) {
              trueHash[newKey] = hash[key];
            }
          } else {
            falseHash[key] = hash[key];
          }
        });

        return [trueHash, falseHash];
      }

      let [correctedEans, vendorPrices] = partitionHash(this.vendorPriceForm.value, '-corrected');
      
      metadata = {
        vendorPrices,
        correctedEans
      }
    }

    this.processingOrder = true;
    this.orderService.nextStatus(order, metadata)
      .pipe(finalize(() => this.dismiss()))
      .subscribe(() => {});
  }

  refuseOrder(order) {
    this.processingOrder = true;
    this.orderService.refuseOrder(order).subscribe(() => this.dismiss());
  }

  cancelOrder(order){
    this.processingOrder = true;
    this.orderService.updateOrder(order, 'DUE', this._vendorPrices).subscribe(()=>this.dismiss());
  }

  updatePosition() {
    if (!this.order.location) return;
    this.location.distanceFrom(this.order.location.lat, this.order.location.lng)
     .subscribe(
       (dist) => {this.distance = dist},
       (err) => {console.log(err)}
     );
  }

  setStyleByStatus(status) {
    switch (status){
      case 'ORDERED':
        this.styleDetail = 'primary-green'
        console.log('ORDERED');
        break;
      case 'ACCEPTED':
        this.styleDetail = 'primary-orange'
        console.log('ACCEPTED');
        break;
      case 'READY':
        this.styleDetail = 'primary-turquoise'
        console.log('READY');
        break;
    }
  }

  isEmpty(obj) {
    for(var key in obj) {
        if(obj.hasOwnProperty(key))
            return false;
    }
    return true;
  }

  triggerValidateFormFields = (formGroup: FormGroup) => {
    //TODO: focus on error -> https://github.com/angular/angular/issues/13158
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);

      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.triggerValidateFormFields(control);
      }
    });
  }
}
