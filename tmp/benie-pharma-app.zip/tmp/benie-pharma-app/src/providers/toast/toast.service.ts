import { Injectable } from '@angular/core';

import { Toast, ToastOptions, ToastController } from 'ionic-angular';
import { NativeAudio } from '@ionic-native/native-audio';

@Injectable()
export class ToastService {

  constructor(private nativeAudio: NativeAudio,
              private toastCtrl: ToastController) {
    console.log('Hello ToastService Provider');

    console.log("toastCtrl", toastCtrl);
    this.nativeAudio.preloadSimple('notification', 'assets/audio/order.mp3').then(
      success => {
        console.log("notification sound preload success");
    }, error => {
        console.error(error);
    });
  }

  private _createAndPresent(toastOptions: ToastOptions, sound: boolean): Toast {
    let toast = this.toastCtrl.create(toastOptions);
    toast.present();

    if(sound) {
      this.nativeAudio.play('notification').then(
        success => {
          console.log("notification sound play success");
        }, error => {
          this.playAudioFallback();
          console.error(error);
      });
    }

    return toast;
  }

  playAudioFallback() {
    console.log('ALTERNATIVE AUDIO');
    let audio = new Audio('assets/audio/order.mp3');
    audio.volume = .8;
    audio.play();
  }

  warning(message: string): Toast {
    return this._createAndPresent({
      message: message,
      position: 'top',
      cssClass: 'warning',
      duration: 3000
    }, false);
  }

  success(message: string): Toast {
    return this._createAndPresent({
      message: message,
      position: 'top',
      cssClass: 'success',
      duration: 3000
    }, false);
  }

  error(message: string): Toast {
    return this._createAndPresent({
      message: message,
      position: 'top',
      cssClass: 'error',
      duration: 3000
    }, false);
  }

  info(message: string): Toast {
    return this._createAndPresent({
      message: message,
      position: 'top',
      cssClass: 'info',
      duration: 3000
    }, true);
  }

  status(message: string): Toast {
    return this._createAndPresent({
      message: message,
      position: 'top',
      cssClass: 'info',
      duration: 0
    }, false);
  }

}
