import { InjectionToken } from "@angular/core";

export let EnvVariables = new InjectionToken("env.variables");