import { Injectable } from '@angular/core';
import { Events } from 'ionic-angular';
import { Network } from 'ionic-native';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/publishReplay'

import { HttpProvider } from "../http/http.provider";
import { AwsUtil } from "../login/aws.service";
import { _USER_LOGIN_EVENT, _USER_LOGOUT_EVENT } from "../login/events.service";
import { Order, STATUS } from "../../models/order.model";

import * as moment from 'moment';
@Injectable()
export class OrderProvider {

  //Lista de pools (observers) para cada status
  private static _ordersCache:any = {};
  private static _ordersPoolMap:any;
  private static _ordersRefresherPoolMap:any = {};
  private static _currentOrderChecksum:any = {};

  private static _userLoggedIn:boolean = true;
  data:any;

  constructor(
      public http: HttpProvider,
      public events:Events,
      public awsUtil:AwsUtil) {
    this.data = null;
    if (!OrderProvider._ordersPoolMap) OrderProvider._ordersPoolMap = {};

    this.events.subscribe(_USER_LOGIN_EVENT, this.onUserLogin);
    this.events.subscribe(_USER_LOGOUT_EVENT, this.onUserLogout);
    Network.onConnect().subscribe(() => {
      OrderProvider._currentOrderChecksum = {};
    })
  }

  private onUserLogin() {
    OrderProvider._currentOrderChecksum = {};
    OrderProvider._userLoggedIn = true;
    for (let status in OrderProvider._ordersRefresherPoolMap) {
      OrderProvider._ordersRefresherPoolMap[status].timeout = 
        setTimeout(OrderProvider._ordersRefresherPoolMap[status].refresher, 10000)
    }
  }

  private onUserLogout() {
    OrderProvider._userLoggedIn = false;
    for (let status in OrderProvider._ordersRefresherPoolMap) {
      clearTimeout(OrderProvider._ordersRefresherPoolMap[status].timeout);
    }
  }

  getSellerUser(): Observable<any>{
    return this.http.get<any>('/seller')
  }

  getOrders(status?:string, canBeCached?:boolean): Observable<Order[]>{
    return new Observable((observable) => {
      if (status && canBeCached && OrderProvider._ordersCache[status]) {
        this.events.publish(status+'_refreshed', OrderProvider._ordersCache[status]);
        observable.next(OrderProvider._ordersCache[status]);
      } else {
        let url = '/orders';
        if (status) {
          url += '?status='+status;
        }
        let obs = this.http.get<Order[]>(url).subscribe((orders) => {
          orders.map((order) => order.orderId = Order.getOrderId(order));
          if (status)
            this.events.publish(status+'_refreshed', orders);
          observable.next(orders);
          OrderProvider._ordersCache[status] = orders;
        }, err => {
          observable.error(err);
        });        
      }

    });
  }

  liveOrdersByStatus(status): Observable<Order[]>{
    if (!OrderProvider._ordersPoolMap[status]) {
      OrderProvider._ordersPoolMap[status] = this._createOrderObservableFor(status);
    }
    return OrderProvider._ordersPoolMap[status];
  }

  updateOrder(order, status, meta?): Observable<any>{
    let userId = order.userId;
    let creationTime = order.creationTime;
    //let changeStatus = {'userId': userId, 'creationTime': creationTime, 'status':status};
    let changeStatus = {'uuid':order.uuid, 'version':order.version, 'status':status, 'meta':meta};

    // console.log("mudando o status de "+order.status+" para "+status);

    return this.http.post('/order', changeStatus);
  }

  refuseOrder(order): Observable<any>{
    return this.http.post('/order-refusal', order);
  }


  nextStatus(order:Order, meta?:any):Observable<any>{
    let lastStatus = order.status;
    let newStatus = STATUS.nextFrom(order.status);
    let obs = this.updateOrder(order, newStatus, meta)
    obs.subscribe(() => { 
      console.log("publishing event: "+ "changed_to_"+newStatus);
      this.events.publish("changed_to_"+newStatus);
      this.awsUtil.recordEvent("from_"+lastStatus+"_to_"+newStatus, {
        "orderUUID": order.uuid,
        "lastStatus": lastStatus,
        "newStatus": newStatus
      })
    }, err => {
      console.log(err);
      this.awsUtil.recordEvent("status_changed_error", {
        "orderUUID": order.uuid,
        "lastStatus": lastStatus,
        "newStatus": newStatus,
        "error": err
      })
    })
    return obs;
  }

  rejectStatus(order:Order):Observable<any>{
    let lastStatus = order.status;
    let obs = this.updateOrder(order, STATUS.NOT_ACCEPTED)
    obs.subscribe(() => {
      this.events.publish("changed_to_"+STATUS.NOT_ACCEPTED)
      this.awsUtil.recordEvent("status_changed_to_"+STATUS.NOT_ACCEPTED, {
        "orderUUID": order.uuid,
        "orderLocator": order.location,
        "date": (new Date()).getTime(),
        "lastStatus": lastStatus,
        "newStatus": STATUS.NOT_ACCEPTED
      })
    }, err => {
      console.log(err);
    })
    return obs;
  }

  resetOrders() {
    // console.log("Resetando orders");
    // this.getOrders().subscribe(orders => {
    //   orders.forEach((o) => {
    //     console.log("o:", o)
    //     this.updateOrder(o, STATUS.ORDERED).subscribe(()=> {

    //     }, (error) => console.log("ChangeError:", error))
    //   });
    // })
    console.log("not available anymore")
  }

  //Cria um observer que envia um next sempre que a lista de orders de um determinado status está diferente do servidor.
  private _createOrderObservableFor(status:string):Observable<Order[]> {
    return Observable.create(observable => {
      let refreshObservable = () => {
        this.http.get<Order[]>('/orders?status='+status)
          .subscribe( orders => {

            // Cria um Id para cada order.
            orders.map((order) => order.orderId = Order.getOrderId(order));
            
            // Verifica se existe mudança em relação a lista atual lista atual.
            if (this._ordersChanged(orders, status)) {
              console.log("orders changed");
              this.events.publish(status+'_refreshed', orders)
              observable.next(orders);
              this.liveOrdersByStatus(status);
            }

          }, err => {
            //observable.error(err);
            console.log("OrderService: error: ", err);
          })
          if (OrderProvider._userLoggedIn)
            OrderProvider._ordersRefresherPoolMap[status].timeout = setTimeout(refreshObservable, 10000);
      }
      OrderProvider._ordersRefresherPoolMap[status] = {
        refresher: refreshObservable
      }
      refreshObservable();
    }).publishReplay(1).refCount();
  }

  private _ordersChanged(newOrders:Order[], status:string):boolean {
    //Cria um checksum da lista de orders vinda do serviço
    var checksum = this._checksum(newOrders);

    //Verifica se esta diferente do atual
    if (OrderProvider._currentOrderChecksum[status] != checksum) {
      OrderProvider._currentOrderChecksum[status] = checksum;
      return true;    
    }
    return false;
  }

  private _checksum(newOrders:Order[]):number {
    return newOrders.reduce((r, order) => {return r + order.orderId + order.version}, 0);
  }

  getCurrentTime():Promise<any> { 
    return new Promise((resolve, reject) => { 
      this.http.get<any>('/time') 
      .subscribe(res => { 
          console.log('Hora atual (timestamp)', res); 
          let syncTime = this._syncTime(res);
          resolve(syncTime);
      }, err => { 
        console.error('Erro ao obter hora atual:', err); 
        reject(); 
      });  
    }); 
  } 

  private _syncTime(currentTime) {
    let nowDate = moment(currentTime);
    let systemDate = moment().valueOf();
    let diff = nowDate.diff(systemDate);

    return diff;
  }
}