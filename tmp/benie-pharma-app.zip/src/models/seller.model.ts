export class SellerUser {
    public user: User;
    public seller: Seller;
}

class User {
    public sellerUuid: string;
    public version: string;
    public cognitoSubscribe: string;
    public email: string;
    public creation: string;
}

class Seller {
    public isActive: boolean;
    public type: string;
    public address: string;
    public companyName: string;
    public email: string;
}