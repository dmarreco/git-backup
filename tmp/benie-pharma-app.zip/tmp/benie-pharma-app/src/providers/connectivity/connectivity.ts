import { Injectable } from '@angular/core';
import { Network } from 'ionic-native';
import { Events, Platform } from 'ionic-angular';
import { Observable, Subscriber } from 'ionic-native/node_modules/rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/publishReplay'

declare var Connection;

@Injectable()
export class ConnectivityProvider {

  onDevice: boolean;
  _isOnline: boolean = true;

  onConnectObs:Observable<any>;
  _onlineSub:Subscriber<any>;
  onDisconnectObs:Observable<any>;
  _offlineSub:Subscriber<any>;

  constructor(public platform: Platform, private events:Events){

    this.onDevice = this.platform.is('cordova');
    this._isOnline = !((Network.type == 'unknown') || (Network.type == 'none'))
    
    var mythis = this;
    this.onConnectObs = new Observable<boolean>((onObs) => {
      this._onlineSub = onObs;
      if (this._isOnline) onObs.next();
      Network.onConnect().subscribe(()=>{
        this._isOnline = true;
        onObs.next();
      })
    }).publishReplay(1).refCount();
    
    this.onDisconnectObs = new Observable<boolean>((onObs) => {
      this._offlineSub = onObs;
      if (!this._isOnline) onObs.next();
      Network.onDisconnect().subscribe(()=>{
        this._isOnline = false;
        onObs.next();
      })
    }).publishReplay(1).refCount();
    
  }

  isOnline(): boolean {
    if(this.onDevice && Network.onConnect){
      return this._isOnline;  //Network.onConnect !== Connection.NONE;
    } else {
      return navigator.onLine; 
    }
  }

  isOffline(): boolean {
    if(this.onDevice && Network.onConnect){
      return !this._isOnline;//Network.onConnect === Connection.NONE;
    } else {
      return !navigator.onLine;
    }
  }

  watchOnline(): Observable<any> {
    return this.onConnectObs;//Network.onConnect().publishReplay(1).refCount();
  }

  watchOffline(): Observable<any> {
    return this.onDisconnectObs;//Network.onDisconnect().publishReplay(1).refCount();
  }

}
