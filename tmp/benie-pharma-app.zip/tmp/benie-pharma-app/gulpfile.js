const gulp = require('gulp');
const run = require('gulp-run');
const argv = require('yargs').argv;
const runSequence = require('run-sequence');

const Promise = require('bluebird');
const awscred = Promise.promisifyAll(require('awscred'));
const s3 = require('gulp-s3-upload')({useIAM:true});

var STAGE = argv.stage || 'development';
var BUCKET = argv.bucket || 'seller.benie.com.br';

var AWS_ACCESS_KEY_ID;
var AWS_SECRET_ACCESS_KEY;

var PATHS = {
    dev: 'development',
    development: 'development',
    test: 'test',
    prod: 'production',
    production: 'production'
}

// AWS credentials and region config
async function awsCredentials() {
    try {
        var cred = await awscred.loadCredentialsAndRegionAsync();
        AWS_ACCESS_KEY_ID = cred.credentials.accessKeyId;
        AWS_SECRET_ACCESS_KEY = cred.credentials.secretAccessKey;
        
        return true;

    } catch(e) {
        console.error('[ERROR] Error on load AWS credentials:', e);
        return;
    }
}

gulp.task('build', async function(done) {
    console.info('[INFO] Deploy starts to stage: ' + PATHS[STAGE]);
    
    return new Promise(function(resolve, reject){
        run('npm run ionic:web:' + PATHS[STAGE], {verbosity: 3}).exec('', function(err){
            if(err) {
                console.error('[ERROR] Build failed');
                reject();    
            }

            console.info('[INFO] Finish build...');
            return resolve();
        });
    });
})

gulp.task('upload-s3', async function(done) {

    if(PATHS[STAGE] !== 'production')
        BUCKET += '/' + PATHS[STAGE];

    console.info('[INFO] Uploading to S3 bucket:', BUCKET);

    return new Promise(function(resolve, reject){
        gulp.src("./www/**/*")
            .pipe(s3({
                Bucket: BUCKET, 
                ACL: 'public-read'
            }, {
                maxRetries: 5
            }))
            .on('end', function(){
                console.info('[INFO] Upload to S3 done!');
                resolve();
            })
            .on('error', function(error) {
                // we have an error
                console(error);
                done(error); 
            });
    });
});

gulp.task('deploy', async function(){
    
    if(!PATHS[STAGE]) {
        console.log('[ERROR] Unrecognized stage parameter: ' + STAGE + ' => ' + PATHS[STAGE]) ;
        return;
    }

    return new Promise(function(resolve){
        runSequence('build', 'upload-s3', function(){
            console.error('[INFO] Finish deploy!');
            resolve();
        });
    });
});

