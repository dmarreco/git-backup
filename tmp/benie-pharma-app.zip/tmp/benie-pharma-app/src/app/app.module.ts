import { NgModule, LOCALE_ID, ErrorHandler } from '@angular/core';
 
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { HttpModule } from '@angular/http';
import { Geolocation } from '@ionic-native/geolocation';
import { NativeAudio } from '@ionic-native/native-audio';
import { FirebaseAnalytics } from '@ionic-native/firebase-analytics';
import { CurrencyMaskModule } from "ng2-currency-mask";

// import { registerLocaleData } from '@angular/common';
// import localePt from '@angular/common/locales/pt';

import { EnvironmentsModule } from './environment-variables/environment-variables.module';
import { CognitoConstants } from '../providers/login/properties.service';

import { LoginPage } from '../pages/login/login';
import { Accepted } from '../pages/accepted/accepted';
import { History } from '../pages/history/history';
import { TabsPage } from '../pages/tabs/tabs';
import { Pending } from '../pages/pending/pending';
import { OrderDetailsPage } from '../pages/order-details/order-details';
import { PopoverMenuPage } from '../pages/popover-menu/popover-menu';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { OrderProvider } from '../providers/order/order.service';
import { ConnectivityProvider } from '../providers/connectivity/connectivity';

import { UserLoginService } from '../providers/login/userLogin.service';
import { CognitoUtil } from "../providers/login/cognito.service";
import { AwsUtil } from "../providers/login/aws.service";
import { EventsService } from "../providers/login/events.service";
import { HttpProvider } from '../providers/http/http.provider';
import { OrderListComponent } from '../components/order-list/order-list';
import { OrderComponent } from '../components/order/order';
import { SortOrderPipe } from '../pipes/sort-order/sort-order';
import { LocationProvider } from '../providers/location/location';
import { PushNotificationService } from '../providers/push-notification/push-notification.service';
import { ToastService } from '../providers/toast/toast.service';
import { HeaderComponent } from '../components/header/header';

@NgModule({
  declarations: [
    MyApp,
    Accepted,
    History,
    OrderDetailsPage,
    Pending,
    TabsPage,
    LoginPage,
    OrderListComponent,
    OrderComponent,
    SortOrderPipe,
    HeaderComponent,
    PopoverMenuPage
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpModule,
    IonicModule.forRoot(MyApp),
    EnvironmentsModule,
    CurrencyMaskModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    Accepted,
    History,
    OrderDetailsPage,
    Pending,
    TabsPage,
    LoginPage,
    PopoverMenuPage
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    OrderProvider,
    ConnectivityProvider,
    UserLoginService,
    CognitoUtil,
    AwsUtil,
    EventsService,
    CognitoConstants,
    HttpProvider,
    Geolocation,
    LocationProvider,
    SortOrderPipe,
    PushNotificationService,
    ToastService,
    NativeAudio,
    FirebaseAnalytics
  ]
})
export class AppModule {}
