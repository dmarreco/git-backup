# Benie Pharma App

Guia resumido de configuração e instalação do ambiente de desenvolvimento do app.

## Tabela de Conteúdos

1. [Pré-requisitos](#pr-requisitos)
2. [Configuração do projeto](#configura-o-do-projeto)
3. [Servindo o projeto no browser](#servindo-o-projeto-no-browser)
4. [Gerando o APK](#gerando-o-apk-debug-mode-)
5. [Release para a Android Store](#release-para-a-android-store)

## Pré-requisitos

- [NodeJS](https://nodejs.org/) ~6.9.2
- [Ionic Framework](https://ionicframework.com/getting-started) ~3.19.0
- [Android SDK](https://developer.android.com/studio/index.html) API 25+
- [Gradle](https://gradle.org/install/) ~4.4.1

## Configuração do projeto

Rodar os seguintes comandos na pasta do projeto.

### Instalação das dependências

```bash
npm install
```

### Configuração da plataforma

```bash
ionic cordova platform add android
```

### Instalação e configuração de plugins

```bash
ionic cordova prepare android
```

## Servindo o projeto no browser

### Ambiente dev

```bash
npm run ionic:serve:dev
```

### Ambiente qa

```bash
npm run ionic:serve:qa
```

### Ambiente prod

```bash
npm run ionic:serve:prod
```
## Gerando o projeto otimizado para browser

### Ambiente dev

```bash
npm run ionic:web:dev
```

### Ambiente qa

```bash
npm run ionic:web:qa
```

### Ambiente prod

```bash
npm run ionic:web:prod
```

## Deploy no S3

### Script de deploy automatizado

O comando aceita os parâmetros *--stage* (Valor defalt 'development'. Valores suportados: *development*, *test* e *production*) e *--bucket* (valor default 'seller.benie.com.br'). 

```bash
gulp deploy --stage AMBIENTE --bucket NOME_BUCKET
```

## Gerando o APK (Debug Mode)

### Somente build

#### Ambiente dev

```bash
npm run ionic:build:dev android
```

#### Ambiente qa

```bash
npm run ionic:build:qa android
```

#### Ambiente prod

```bash
npm run ionic:build:prod android
```

### Build e Instalação via USB

#### Ambiente dev

```bash
npm run ionic:run:dev android
```

#### Ambiente qa

```bash
npm run ionic:run:qa android
```

#### Ambiente prod

```bash
npm run ionic:run:prod android
```

## Release para a Android Store

Pendente da criação da Keystore.

[Guia para publicação do Ionic](https://ionicframework.com/docs/v1/guide/publishing.html#android-publishing)
