import { 
  Component, Input, 
  Output, EventEmitter,
  trigger, sequence, transition, animate, style, state
} from '@angular/core';
import { Events } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';

import { HttpProvider } from '../../providers/http/http.provider'; 

import { OrderProvider } from '../../providers/order/order.service';
import { SortOrderPipe } from '../../pipes/sort-order/sort-order';

import { Order, STATUS } from '../../models/order.model';
import { OrderComponent } from '../order/order';

/**
 * Generated class for the OrderListComponent component.
 *
 * See https://angular.io/docs/ts/latest/api/core/index/ComponentMetadata-class.html
 * for more info on Angular Components.
 */
@Component({
  selector: 'order-list',
  templateUrl: 'order-list.html',
  animations: [
    trigger('anim', [
      transition('* => void', [
        animate(100, 
          style({ height: "0px" })
        )      
      ])
    ])
  ]
})
export class OrderListComponent {

  private _status:string = null;
  @Input() set status(val: string) {
    this._status = val;
    if (this._isLive !== null) {
      this.observeStatus();
    }
  };

  private _isLive:boolean = null;
  @Input() set live(val: boolean) {
    this._isLive = val;
    if (this._status !== null) {
      this.observeStatus();
    }
  };

  @Input() colorCard: string;

  @Output() showDetail:EventEmitter<Order> = new EventEmitter<Order>();
  @Output() accept:EventEmitter<Order> = new EventEmitter<Order>();
  @Output() reject:EventEmitter<Order> = new EventEmitter<Order>();
  @Output() acceptError:EventEmitter<any> = new EventEmitter<any>();
  @Output() rejectError:EventEmitter<any> = new EventEmitter<any>();
  
  @Output() listAdd:EventEmitter<any> = new EventEmitter<any>();
  @Output() listRemove:EventEmitter<any> = new EventEmitter<any>();
  @Output() listChange:EventEmitter<any> = new EventEmitter<any>();

  orders: Order[];
  currentTime: number;
  admin: boolean;

  private syncTime: number;
  private _timeRefresher;
  private _syncTimeOut;

  constructor(
    private orderService:OrderProvider,
    private sortOrder:SortOrderPipe,
    private events:Events,
    private http:HttpProvider
  ) {
    this.timeRefresher();
    this.syncTimeOut();
    this.checkAdminStatus();
  };

  observeStatus() {
    if (this._isLive) {
      this.orderService.liveOrdersByStatus(this._status)
        .subscribe(
          orders => {
            this.listChange.emit();
            this._changeOrders(orders);
          },
          error => {
            console.log("OrderList:",error);
          }
        );      
    } else {
      this.refreshOrder();
    }
  }

  public refreshOrder(canBeCached?:boolean):Observable<Order[]> {
    let obs = this.orderService.getOrders(this._status, canBeCached);
    obs.subscribe(
      orders => this._changeOrders(orders),
      error => console.log(error)
    );
    return obs;
  }

  _changeOrders(orders:Order[]) {
    console.log("publishing event: "+this._status+'_refreshed');
    if (!this.orders) {
      this.orders = orders;
      return;
    }

    let currentIdMap = this.orders.map((o) => o.orderId + o.version);
    let newIdMap = orders.map((o) => o.orderId + o.version);

    let toDelete = this.orders.filter((o) => {
      return newIdMap.indexOf(o.orderId + o.version) == -1;
    })
    toDelete.forEach(o => {
      this.orders.splice(this.orders.indexOf(o), 1);
    })
    if (toDelete.length > 0) this.listRemove.emit();
    
    let toInsert = orders.filter(o => {
      return currentIdMap.indexOf(o.orderId + o.version) == -1;
    })
    toInsert.forEach(o => {
      this._insertInOrder(o);
    })
    if (toInsert.length > 0) this.listAdd.emit(toInsert);

    if (this._status == STATUS.ACCEPTED) {
      console.log("inserting...");
    }

    //this.sortOrder.transform(this.orders);

  }

  _insertInOrder(o:Order) {
      var idx=0;
      for (idx=0;idx<this.orders.length;idx++) {
        if (this.orders[idx].deadlineTime > o.deadlineTime) break;
      }
      //if (idx > 0) idx -= 1;
      this.orders.splice(idx,0,o);
      console.log("reinserindo em: "+idx);
  }

  showOrderDetail(order:Order) {
    this.showDetail.emit(order);
  }

  acceptOrder(order:OrderComponent) {
    //this.accept.emit(order);

    this.orderService.nextStatus(order._order).subscribe(
      () => { 
        this.orders.splice(this.orders.indexOf(order.order), 1);
        this.accept.emit(order.order);
      },
      (error) => { 
        this.acceptError.emit(error)
        order.resetStyle();
      } 
    );
  }

  rejectOrder(order:OrderComponent) {

    if (order._order.status !== STATUS.ORDERED) return;

    this.orderService.rejectStatus(order._order).subscribe(
      () => {
        this.orders.splice(this.orders.indexOf(order._order), 1);
        this.reject.emit(order._order);
      },
      (error) => {
        this.rejectError.emit(error)
        order.resetStyle();
      }
    )
    
  }

  timeRefresher() {
    if(!this.syncTime) {
      this.orderService.getCurrentTime().then((res) => {
        this.syncTime = res;
      });
    }

    this.currentTime = new Date().getTime() + this.syncTime;
    this._timeRefresher = setTimeout(() => this.timeRefresher(), 1000);
  }

  syncTimeOut() {
    clearInterval(this._syncTimeOut);
    this._syncTimeOut = setInterval(() => {
      this.syncTime = 0;
    }, 180000);
  };

  public checkAdminStatus():Observable<any> {
    let obs = this.orderService.getSellerUser();
    obs.subscribe(
      sellerUser => this.admin = sellerUser.seller.type === 'admin',
      error => console.log(error)
    );
    return obs;
  }

  ngOnDestroy() {
    clearTimeout(this._timeRefresher);
    clearInterval(this._syncTimeOut);
  }
}
