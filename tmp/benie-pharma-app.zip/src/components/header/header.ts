import { Component, Input, Output, EventEmitter } from '@angular/core';
import { PopoverController, Popover } from 'ionic-angular';

import { PopoverMenuPage } from '../../pages/popover-menu/popover-menu';

@Component({
  selector: 'header',
  templateUrl: 'header.html'
})
export class HeaderComponent {

  @Input() title:string;
  @Input() headerColor:string;
  @Output() titleClicked: EventEmitter<any> = new EventEmitter<any>();

  private _menu: Popover; 

  constructor(private popoverCtrl: PopoverController) {
  }

  ionViewDidLoad(){
    console.log(this.headerColor);
  }

  emitTitleClicked() {
    this.titleClicked.emit();
  }

  openMenu(event) {
    if(!this._menu) 
      this._menu = this.popoverCtrl.create(PopoverMenuPage);
    this._menu.present({
      ev: event
    });
  }
}
