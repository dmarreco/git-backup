import { Pipe, PipeTransform } from '@angular/core';
import { Order } from '../../models/order.model'

/**
 * Generated class for the SortOrderPipe pipe.
 *
 * See https://angular.io/docs/ts/latest/guide/pipes.html for more info on
 * Angular Pipes.
 */
@Pipe({
  name: 'sortOrder'
})
export class SortOrderPipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
  transform(arr: Order[]): Order[] {
    if (!arr) return arr;
    arr.sort((a:Order, b:Order) => {
      if (a.deadlineTime == b.deadlineTime) return 0;

      return a.deadlineTime > b.deadlineTime ? 1 : -1;
    });
    return arr
  }
}
