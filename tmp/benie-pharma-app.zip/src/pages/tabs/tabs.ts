import { Component, ViewChild, ElementRef } from '@angular/core';
import { Events, Toast } from 'ionic-angular';
import { Accepted } from '../accepted/accepted';
import { History } from '../history/history';
import { Pending } from '../pending/pending';
import { ConnectivityProvider } from '../../providers/connectivity/connectivity';
import { OrderProvider } from '../../providers/order/order.service';
import { ToastService } from '../../providers/toast/toast.service';
import { Order, STATUS } from '../../models/order.model';
import { Tabs } from 'ionic-angular/navigation/nav-interfaces';
import { Element } from '@angular/compiler';


@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  @ViewChild('tabsMenu') tabRef: ElementRef;

  tab1Root = Pending;
  tab2Root = Accepted;
  tab3Root = History;

  public orderedTabCount = 0;
  public acceptedTabCount = 0;
  public readyTabCount = 0;

  private static connectivityToast:Toast;
  constructor(
    public events: Events,
    private connectivity:ConnectivityProvider,
    private orderService:OrderProvider,
    private toast:ToastService) {

  }

  onOffline() {   
    if (this && !TabsPage.connectivityToast) { 
      TabsPage.connectivityToast = this.toast.status("Não conseguimos detectar a rede. Verifique sua conexão com a internet.");
    }
  }

  ionViewDidEnter() {
    console.log(this.tabRef);
  }

  ionViewDidLoad(){

    this.connectivity.watchOffline()
      .subscribe(() => {
        console.log("Tabs warning offline");
        this.onOffline();
      })

    this.connectivity.watchOnline()
      .subscribe(() => {
        console.log("Tabs warning online");
        if(TabsPage.connectivityToast) {
          TabsPage.connectivityToast.dismiss();
          TabsPage.connectivityToast = null;
        }
      })

    this.events.subscribe('changed_to_'+STATUS.ACCEPTED,() =>{
      this.increaseTabCount();
      this.refreshOrders();
    });

    this.events.subscribe('changed_to_'+STATUS.READY,() =>{
      if (this.acceptedTabCount > 0){
        this.decreaseTabCount();
      }
      this.refreshOrders();
    });

    this.events.subscribe('changed_to_' + STATUS.SENT, () => {
      if (this.readyTabCount > 0){
        this.readyTabCount  = this.readyTabCount - 1;
      }
      this.refreshOrders();
    });

    this.events.subscribe(STATUS.READY+'_refreshed',(orders:Order[]) => {
      this.readyTabCount = orders.length;
    });

    this.events.subscribe(STATUS.ACCEPTED+'_refreshed',(orders:Order[]) => {
      this.acceptedTabCount = orders.length;
    });

    this.events.subscribe(STATUS.ORDERED+'_refreshed',(orders:Order[]) => {
      this.orderedTabCount = orders.length;
      this.refreshOrders();
    });
    

  }

  refreshOrders() {
    this.orderService.getOrders(STATUS.ACCEPTED).subscribe((orders)=> {});
    this.orderService.getOrders(STATUS.READY).subscribe((orders)=> {});
    this.orderService.getOrders(STATUS.NOT_ACCEPTED).subscribe((orders)=> {});
  }

  getTabCount(){
    return this.acceptedTabCount;
  }

  increaseTabCount(){
    this.acceptedTabCount = this.acceptedTabCount +1;
  }

  decreaseTabCount(){
    this.acceptedTabCount = this.acceptedTabCount -1;
  }

  setTabCount(count){
    this.acceptedTabCount = count;
  }
}
