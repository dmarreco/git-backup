import { Injectable } from '@angular/core';
import { Headers, RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { HttpProvider } from "../http/http.provider";
import { Order } from "../../models/order.model";


@Injectable()
export class OrderProvider {

  data:any;

  constructor(
    public http: HttpProvider) {
    this.data = null;
  }

  getSellerUser(): Observable<any>{
    return this.http.get<any>('/seller')
  }
  
  getOrders(): Observable<Order[]>{
    return this.http.get<Order[]>('/orders')
  }

  getOrdersByStatus(status): Observable<Order[]>{
    return this.http.get<Order[]>('/orders?status='+status);
  }

  updateOrder(order, status){
    return new Promise(resolve => {
    let userId = order.userId;
    let creationTime = order.creationTime;
    let changeStatus = {'userId': userId, 'creationTime': creationTime, 'status':status};

    this.http.post('/order', changeStatus)
        .subscribe(res => {
          resolve(res);
        });
    });
  }

}