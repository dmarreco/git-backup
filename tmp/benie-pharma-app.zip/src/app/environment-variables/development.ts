export const devVariables = {
	_REGION: "us-west-2",
	_IDENTITY_POOL_ID: "us-west-2:3a89f0c4-ef73-4aad-890b-81a1cc90ae0a",
	_USER_POOL_ID: "us-west-2_UIt9t4BRY",
	_CLIENT_ID: "7e4f8lqdjscgq24h04fcaeh80t",
	_MOBILE_ANALYTICS_APP_ID: "62b29b879d8a46129a9283497117305c",
	_POOL_DATA: {
	    UserPoolId: "us-west-2_UIt9t4BRY",
	    ClientId: "7e4f8lqdjscgq24h04fcaeh80t"
	},

	_ENDPOINT: "https://0al0adauua.execute-api.us-west-2.amazonaws.com/dev",
	_ENV: "DEV"
}