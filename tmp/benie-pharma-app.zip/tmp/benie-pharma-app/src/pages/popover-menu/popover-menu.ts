import { Component } from '@angular/core';
import { ViewController } from 'ionic-angular';

import {UserLoginService} from "../../providers/login/userLogin.service";

@Component({
  selector: 'page-popover-menu',
  templateUrl: 'popover-menu.html',
})
export class PopoverMenuPage {

  private username: string;

  constructor(
    private viewCtrl: ViewController,
    private userService: UserLoginService) {
      this.getUsername();
  }

  getUsername() {
    this.username = localStorage.getItem('benie-pharma-app_username');
  }

  logout() {
    console.log("logout");
    this.viewCtrl.dismiss();
    this.userService.logout();
  }
}
