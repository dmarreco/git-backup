/*
  cart: Cart
  creationTime: 1513109093437
  location: {zip: "22081-040", number: "22", country: "BR", address: "R. Canning, 22 (ap 104) - Ipanema, Rio de Janeiro - RJ, 22081-040, Brazil", route: "R. Canning", …}
  status: "ORDERED"
  totalPrice: 245.06
  userId: "1643384962398576"
  version: 1513109093437
*/
export class Order {
  public cart: OrderItem[];
  public customer:Customer;
  public creationTime: number;
  public location: Location;
  public status: string;
  public totalPrice: number;
  public userId: string;
  public orderId: number;
  public version: number;
  public uuid: string;
  public invoice: any;
  public deadlineTime: number;

  private static hashCode (s) {
    if (s) {
      return s.split("").reduce(function(a,b){a=((a<<5)-a)+b.charCodeAt(0);return a&a},0);              
    } else {
      return 0;
    }
  }
  public static getOrderId(order:Order):number {
    return order.creationTime + Order.hashCode(order.uuid);
  }
}

export class OrderItem {
  public ammount: number;
  public product: Product;
}

/*
  activeIngredient: "Isometepteno + Dipirona Sódica + Cafeína"
  drugEan: "7896641808623 "
  drugFormDescription: "30+300+30mg"
  drugFormPresentation: "10 drágeas"
  drugLabName: "Takeda"
  drugType: "Referência"
  id: "5373"
  price: 230.73
  shortName: "Neosaldina"
  type: "DRUG"
*/

export class Product {
  private activeIngredient: string;
  private drugEan: string;
  private drugFormDescription: string;
  private drugFormPresentation: string;
  private drugLabName: string;
  private drugType: string;
  private id: string;
  private price: number;
  private regularPrice: number;
  private shortName: string;
  private type: string;

  constructor() { }

  get _price() {
    return this._price;
  }
}

/*
  address: "R. Píres de Almeida, 65 (ap 301) - Laranjeiras, Rio de Janeiro - RJ, 22240-150, Brazil"
  complement: "ap 301"
  country: "BR"
  county: "Rio de Janeiro"
  gmapsId: "Ek5SLiBQw61yZXMgZGUgQWxtZWlkYSwgNjUgLSBMYXJhbmplaXJhcywgUmlvIGRlIEphbmVpcm8gLSBSSiwgMjIyNDAtMTUwLCBCcmFzaWw"
  lat: -22.9378698
  lng: -43.1942885
  neighborhood: "Laranjeiras"
  number: "65"
  route: "R. Píres de Almeida"
  state: "RJ"
  zip: "22240-150"
*/

export class Location { 
  public address: string;
  public complement: string;
  public country: string;
  public county: string;
  public gmapsId: string;
  public lat: number;
  public lng: number;
  public neighborhood: string;
  public number: string;
  public route: string;
  public state: string;
  public zip: string;
}

export class STATUS {
  public static ORDERED: string = "ORDERED";
  public static ACCEPTED:string = "ACCEPTED";
  public static READY: string = "READY";
  public static SENT: string = "SENT";
  public static NOT_ACCEPTED: string = "NOT_ACCEPTED";

  public static nextFrom(s:string):string {
    switch (s) {
      case STATUS.ORDERED: return STATUS.ACCEPTED;
      case STATUS.ACCEPTED: return STATUS.READY;
      case STATUS.READY: return STATUS.SENT;
    }
    return STATUS.NOT_ACCEPTED;
  }
}

export class Customer {
  public cpf: string;
  public firstName: string;
  public lastName: string;
  public phone: string;
  public profilePic: string;
}