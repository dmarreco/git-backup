import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { Geolocation } from '@ionic-native/geolocation';



/*
  Generated class for the LocationProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
@Injectable()
export class LocationProvider {

  private _currentLocation:LocationLatLng;

  constructor(public location:Geolocation) {

  }

  public getLocationLatLng():Observable<LocationLatLng> {
    return new Observable<LocationLatLng>(observer => {
      if (this._currentLocation){
        observer.next(this._currentLocation);
        observer.complete();
      } else {
        this.location.getCurrentPosition()
          .then(loc => {
            this._currentLocation = 
              new LocationLatLng(loc.coords.latitude, loc.coords.longitude);
            observer.next(this._currentLocation);
            observer.complete();
          })
          .catch(err => {
            console.log('Error on get current position:', err);
          })
      }
    })
  }

  public distanceFrom(lat, lng):Observable<number> {
    return new Observable<number> (observer => {
      if (lat===undefined || lat===null || lng===undefined || lng===null) {
        observer.error("Não foi possivel calcular a distancia");
      } else {
        this.getLocationLatLng().subscribe((loc:LocationLatLng) => {
          observer.next(this._distance(lat, lng, loc.lat, loc.lng, 'K'));
        });        
      }
    })
  }

  private _distance (lat1, lon1, lat2, lon2, unit): number {
      var radlat1 = Math.PI * lat1/180
      var radlat2 = Math.PI * lat2/180
      var theta = lon1-lon2
      var radtheta = Math.PI * theta/180
      var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
      dist = Math.acos(dist)
      dist = dist * 180/Math.PI
      dist = dist * 60 * 1.1515
      if (unit=="K") { dist = dist * 1.609344 }
      if (unit=="N") { dist = dist * 0.8684 }
      return dist    
  }

}

export class LocationLatLng {
  lat:number;
  lng:number;

  constructor(lat?:number, lng?:number) {
    this.lat = lat;
    this.lng = lng
  }
}