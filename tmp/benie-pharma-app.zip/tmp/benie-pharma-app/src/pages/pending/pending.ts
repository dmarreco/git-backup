import { Component, ViewChild } from '@angular/core';
import { Events, ModalController } from 'ionic-angular';

import { OrderDetailsPage } from '../order-details/order-details';
import { OrderProvider } from '../../providers/order/order.service';
import { ToastService } from '../../providers/toast/toast.service';
import { Order, STATUS } from '../../models/order.model';
import { OrderListComponent } from '../../components/order-list/order-list';

@Component({
  selector: 'page-pending',
  templateUrl: 'pending.html',
})
export class Pending {

  @ViewChild('orderList')
  orderList:OrderListComponent;

  public orders:Order[];
  renewOrders:any;
  loader: any;

  constructor(
    public orderService: OrderProvider, 
    public events: Events, 
    public modalCtrl: ModalController,
    public toastService: ToastService) {
    this.renewOrders = [];
  }

  ionViewDidLoad(){
    //this.notifyBrownser('Hi there!!!');
    //this.newOrders('Novo pedido no Benie!');
  }

  viewOrderDetails(order){
    let pageDetails = this.modalCtrl.create(OrderDetailsPage, {order: order});
    pageDetails.onDidDismiss(() => {
    });
    pageDetails.present();
  }

  acceptOrder(order:Order) {
    this.toastService.success("Pedido atendido!");
  }

  rejectOrder(order:Order) {
    this.toastService.success("Pedido enviado para o Histórico");
  }

  acceptError(error:any) {
    console.log(error);
  }

  rejectError(error:any) {
    console.log(error);
  }

  resetOrders() {
    //this.orderService.resetOrders();
  }

  newOrders(insertList) {
    console.log('INSERT LIST:');
    console.log(insertList);

    let addCount = insertList.length;
    this.toastService.info(insertList.length + " novos pedidos!");
    
    // insertList.forEach(value => {
    //   console.log(value);
    //   this.notifyBrowser(value);
    // });
    this.notifyBrowser('Benie Pharma');
  }

  notifyBrowser(message?) {
    let _Notification = window["Notification"];
    let _options = {
      body: 'Novo pedido no Benie!',
      icon: 'http://benie-bot-br.s3.amazonaws.com/test/images/product-default-icon.png'
    }

    if (!("Notification" in window)) {
      console.warn("Notificações não suportadas no browser!");
    } else if (_Notification.permission === "granted") {
      var notification = new Notification(message, _options);
    } else if (_Notification.permission !== "denied") {
      _Notification.requestPermission(function (permission) {
        if (permission === "granted") {
          var notification = new Notification(message, _options);
        }
      });
    }
  }
}
